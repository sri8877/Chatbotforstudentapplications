const express = require('express');
const cors = require('cors');
// const bodyParser = require('body-parser'); // Not strictly needed if using express.json()
const admin = require('./firebase'); // our firebase.js
const fetch = require('node-fetch');
require('dotenv').config();
// Then access variables via process.env.VARIABLE_NAME
const app = express();
app.use(cors());
app.use(express.json()); // parse JSON bodies

// Example: get references to Firestore or Realtime DB
const { getFirestore } = require('firebase-admin/firestore');   const db = getFirestore(); // if you're using Firestore
// const rtdb = admin.database(); // if you're using Realtime Database

// Add authentication middleware
const authenticateUser = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      // Allow anonymous access but mark as unauthenticated
      req.user = { uid: 'anonymous', isAnonymous: true };
      return next();
    }
    
    const token = authHeader.split('Bearer ')[1];
    const decodedToken = await admin.auth().verifyIdToken(token);
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    req.user = { uid: 'anonymous', isAnonymous: true };
    next();
  }
};

// Apply middleware to routes that need authentication
app.use('/chat', authenticateUser);

const md = require('markdown-it')({
  html: false, // For security
  breaks: true,
  linkify: true
});

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_API_URL = process.env.GEMINI_API_URL;

// Add HTTP/HTTPS agent configuration with proxy support
const https = require('https');
const HttpsProxyAgent = require('https-proxy-agent');

// Function to create appropriate agent based on environment
function createAgent() {
  // Check for proxy in environment variables
  const proxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
  
  if (proxy) {
    console.log('Using proxy:', proxy);
    return new HttpsProxyAgent(proxy);
  }
  
  return new https.Agent({
    timeout: 60000, // Increase timeout to 60 seconds
    keepAlive: true,
    rejectUnauthorized: false // Try this if SSL/TLS is an issue
  });
}

// Add this after the collegeInfo object
// Store conversation history in memory (for users without authentication)
const conversationHistory = {};

// Function to handle Gemini API request with retries
async function makeGeminiRequest(userMessage, userId, retries = 3) {
  const apiUrl = `${GEMINI_API_URL}?key=${GEMINI_API_KEY}`;
  const agent = createAgent();
  
  // Initialize conversation history for this user if it doesn't exist
  if (!conversationHistory[userId]) {
    conversationHistory[userId] = [];
  }
  
  // Add the current message to history
  conversationHistory[userId].push({ role: "user", content: userMessage });
  
  // Keep only the last 5 messages to avoid token limits
  if (conversationHistory[userId].length > 10) {
    conversationHistory[userId] = conversationHistory[userId].slice(-10);
  }
  
  // Format the conversation history for Gemini API
  const formattedHistory = conversationHistory[userId].map(msg => ({
    role: msg.role,
    parts: [{ text: msg.content }]
  }));
  
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      console.log(`Attempt ${attempt} - Making request to Gemini API`);
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [
            {
              role: "system",
              parts: [
                { 
                  text: `You are an AI assistant for college admissions and applications. 
                         Your role is to help prospective students with their college application process.
                         You can provide information about any college, their programs, admission requirements, and application processes.
                         If asked about a specific college, provide accurate information about that college.
                         If no specific college is mentioned, provide general guidance about college applications.
                         Remember the context of the conversation and be able to answer follow-up questions.`
                }
              ]
            },
            ...formattedHistory
          ]
        }),
        agent,
        timeout: 60000 // 60 second timeout
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      
      // Add the bot's response to the conversation history
      if (data.candidates && data.candidates[0] && data.candidates[0].content) {
        const content = data.candidates[0].content;
        if (content.parts && content.parts[0] && content.parts[0].text) {
          conversationHistory[userId].push({ 
            role: "assistant", 
            content: content.parts[0].text 
          });
        }
      }
      
      return data;
    } catch (error) {
      console.error(`Attempt ${attempt} failed:`, error.message);
      
      if (attempt === retries) {
        // If this was the last attempt, throw the error
        throw error;
      }
      
      // Wait before retrying (exponential backoff)
      const delay = Math.min(1000 * Math.pow(2, attempt), 10000);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

// Add this to your server.js
const collegeInfo = {
  'general': {
    'admission_process': 'The general college admission process typically involves:\n1. Research colleges and programs\n2. Check eligibility criteria\n3. Prepare required documents\n4. Submit application before deadlines\n5. Track application status\n6. Respond to admission offer',
    'required_documents': 'Common required documents for college applications include:\n- Academic transcripts\n- ID proof\n- Passport-sized photographs\n- Entrance exam scores (if applicable)\n- Letters of recommendation (for some programs)\n- Statement of purpose (for some programs)',
    'application_tips': 'Tips for college applications:\n1. Start early\n2. Keep documents ready\n3. Meet all deadlines\n4. Follow up on your application\n5. Maintain good academic records\n6. Prepare for entrance exams if required'
  }
};

// Function to check if a message is asking about college info
function getCollegeInfo(message) {
  const lowerMessage = message.toLowerCase();
  
  // Check for general queries first
  if (lowerMessage.includes('how to apply') || lowerMessage.includes('admission process')) {
    return collegeInfo.general.admission_process;
  }
  
  if (lowerMessage.includes('document') || lowerMessage.includes('certificate')) {
    return collegeInfo.general.required_documents;
  }
  
  if (lowerMessage.includes('tips') || lowerMessage.includes('advice')) {
    return collegeInfo.general.application_tips;
  }
  
  // If no matching general info is found, return null to use Gemini API
  return null;
}

// Route for the chatbot
app.post('/chat', authenticateUser, async (req, res) => {
  try {
    const userMessage = req.body.message || '';
    const userId = req.user.uid || 'anonymous';

    // First check if we have a local answer
    const localAnswer = getCollegeInfo(userMessage);
    if (localAnswer) {
      const formattedReply = md.render(localAnswer);
      
      // Even for local answers, store in conversation history
      if (!conversationHistory[userId]) {
        conversationHistory[userId] = [];
      }
      conversationHistory[userId].push({ role: "user", content: userMessage });
      conversationHistory[userId].push({ role: "assistant", content: localAnswer });
      
      return res.json({ 
        reply: localAnswer,
        replyFormatted: formattedReply
      });
    }

    // If no local answer, try Gemini API
    try {
      const data = await makeGeminiRequest(userMessage, userId);
      
      let botReply = "I apologize, but I'm having trouble connecting to my knowledge base right now. Please try again in a moment.";
      
      if (data.candidates && data.candidates[0] && data.candidates[0].content) {
        const content = data.candidates[0].content;
        if (content.parts && content.parts[0] && content.parts[0].text) {
          botReply = content.parts[0].text;
        }
      }

      // Format bot reply with markdown
      const formattedReply = md.render(botReply);

      // Store in Firebase if we have a valid conversation
      if (req.user && !req.user.isAnonymous) {
        const conversation = db.collection('conversations').doc();
        await conversation.set({
          startedAt: admin.firestore.FieldValue.serverTimestamp(),
          userId: req.user.uid,
          applicationStage: 'start',
          applicationData: {}
        });

        await conversation.collection('messages').add({
          content: userMessage,
          sender: 'user',
          timestamp: admin.firestore.FieldValue.serverTimestamp()
        });

        await conversation.collection('messages').add({
          content: botReply,
          contentFormatted: formattedReply,
          sender: 'bot',
          timestamp: admin.firestore.FieldValue.serverTimestamp()
        });
      }

      return res.json({ 
        reply: botReply,
        replyFormatted: formattedReply
      });
    } catch (error) {
      console.error('Gemini API error:', error);
      
      // Return a fallback response
      const fallbackReply = "I apologize, but I'm having trouble connecting to my knowledge base right now. Please try again later or contact the college admissions office directly for assistance.";
      const formattedReply = md.render(fallbackReply);
      
      return res.json({
        reply: fallbackReply,
        replyFormatted: formattedReply
      });
    }
  } catch (error) {
    console.error('Error in /chat endpoint:', error);
    return res.status(500).json({ 
      error: 'Server error', 
      message: error.message 
    });
  }
});

// Add a new route to fetch conversation history
app.get('/conversations', authenticateUser, async (req, res) => {
  try {
    const userId = req.user.uid;
    
    // Skip history for anonymous users
    if (userId === 'anonymous') {
      return res.json({ conversations: [] });
    }
    
    const conversationsSnapshot = await db.collection('conversations')
      .where('userId', '==', userId)
      .orderBy('startedAt', 'desc')
      .limit(10)
      .get();
    
    const conversations = [];
    
    for (const doc of conversationsSnapshot.docs) {
      const convoData = doc.data();
      
      // Get first message to use as preview
      const messagesSnapshot = await doc.ref.collection('messages')
        .orderBy('timestamp', 'asc')
        .limit(1)
        .get();
      
      let preview = 'Empty conversation';
      if (!messagesSnapshot.empty) {
        preview = messagesSnapshot.docs[0].data().content;
        // Truncate if too long
        if (preview.length > 60) {
          preview = preview.substring(0, 57) + '...';
        }
      }
      
      conversations.push({
        id: doc.id,
        startedAt: convoData.startedAt.toDate().toISOString(),
        preview
      });
    }
    
    res.json({ conversations });
  } catch (error) {
    console.error('Error fetching conversations:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Add endpoint to get a specific conversation
app.get('/conversations/:id', authenticateUser, async (req, res) => {
  try {
    const convoId = req.params.id;
    const userId = req.user.uid;
    
    // Get conversation
    const convoDoc = await db.collection('conversations').doc(convoId).get();
    
    if (!convoDoc.exists) {
      return res.status(404).json({ error: 'Conversation not found' });
    }
    
    // Security check
    const convoData = convoDoc.data();
    if (convoData.userId !== userId && userId !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    // Get messages
    const messagesSnapshot = await convoDoc.ref.collection('messages')
      .orderBy('timestamp', 'asc')
      .get();
    
    const messages = messagesSnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        content: data.content,
        sender: data.sender,
        timestamp: data.timestamp.toDate().toISOString()
      };
    });
    
    res.json({
      id: convoDoc.id,
      startedAt: convoData.startedAt.toDate().toISOString(),
      messages
    });
  } catch (error) {
    console.error('Error fetching conversation:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Add endpoint for feedback
app.post('/feedback', authenticateUser, async (req, res) => {
  try {
    const { messageId, rating, comments } = req.body;
    
    // Parse the messageId to get conversation and message info
    const [conversationId, timestamp] = messageId.split('|');
    
    // If it's a new conversation that wasn't saved yet
    if (conversationId === 'new') {
      return res.json({ success: true }); // Just acknowledge it
    }
    
    // Store feedback in Firebase
    await db.collection('feedback').add({
      messageId,
      conversationId,
      rating,
      comments,
      userId: req.user?.uid || 'anonymous',
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving feedback:', error);
    res.status(500).json({ error: 'Failed to save feedback' });
  }
});

// Serve static files from the public directory
app.use(express.static('public'));

// Start the server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

function getNextApplicationStep(currentStep, userInfo) {
  const steps = {
    'start': {
      message: 'Welcome to the College Application Assistant! Let\'s start with your basic information. What is your full name?',
      nextStep: 'name'
    },
    'name': {
      message: 'Great! Which college(s) are you interested in applying to?',
      nextStep: 'college'
    },
    'college': {
      message: 'What program or course are you interested in applying for at this college?',
      nextStep: 'program'
    },
    'program': {
      message: 'What is your previous educational qualification?',
      nextStep: 'education'
    },
    'education': {
      message: 'Do you have any specific questions about the application process for this college and program?',
      nextStep: 'questions'
    },
    'questions': {
      message: 'I can help you with information about:\n1. Admission requirements\n2. Application deadlines\n3. Required documents\n4. Entrance exams\n5. Fee structure\nWhat would you like to know more about?',
      nextStep: 'general'
    }
  };
  
  return steps[currentStep] || {
    message: 'Is there anything else you would like to know about the college application process?',
    nextStep: 'general'
  };
}

