const admin = require('firebase-admin');
const serviceAccount = require('./chatbotforstudentapplications-firebase-adminsdk-fbsvc-acb8aca6cc.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://chatbotforstudentapplications.firebaseio.com" // Replace <your-project-id> with your actual Firebase project ID
});

module.exports = admin;
